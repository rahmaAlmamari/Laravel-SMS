<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class SmsallController extends Controller
{
    public function smsall(){

        $basic  = new \Vonage\Client\Credentials\Basic("94c283df", "6L5gd0yrDAnutYCp");
        $client = new \Vonage\Client($basic);
        //$records = User::select('phone')->get();
        //$records = User::get('phone');
        //$records = DB::table('users')->get('phone')->toArray();
        //$records = DB::table('users')->get('phone')->toJson();
        //print_r($records);
        //$records = User::all();

        /*$records = DB::table('users')->get();
        foreach ($records as $record)
        {
          var_dump($record->phone);
          //return ($record->phone);
        }*/
        $receiverNumbers = User::get();

        foreach ($receiverNumbers as $receiverNumber)
        {
            $value = json_encode($receiverNumber->phone);
            $response = $client->sms()->send(
                new \Vonage\SMS\Message\SMS($value, 'Rahma', 'Good job rahma you do it in right way')
            );
            $message = $response->current();
            if ($message->getStatus() == 0) {
                echo "The message was sent successfully\n";
            } else {
                echo "The message failed with status: " . $message->getStatus() . "\n";
            }
        }

        

    }
}
